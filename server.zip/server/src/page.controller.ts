import { Controller, Get, Param, Patch } from '@nestjs/common';
import { PageService } from './page.service';

@Controller('pages')
export class PageController {
  constructor(private pageService: PageService) {}

  @Get('/:pageId')
  getPage(@Param('pageId') pageId: string) {
    return this.pageService.getPage(pageId);
  }

  @Patch('/:pageId')
  patchPage() {
    return this.pageService.patchPage();
  }
}
