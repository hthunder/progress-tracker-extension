import { HttpService } from '@nestjs/axios';
import { ForbiddenException, Injectable } from '@nestjs/common';
import { catchError, map } from 'rxjs';

@Injectable()
export class PageService {
  constructor(private readonly httpService: HttpService) {}

  getPage(pageId: string) {
    return this.httpService
      .get(`https://api.notion.com/v1/pages/a60cf6646de74a3987cdcf82a6adb45d`, {
        headers: {
          Authorization: `Bearer secret_iNcmYgO0zH7ftoXF9SiXlyiCJw71VVmZXeqUPde6NfF`,
          'Notion-Version': '2022-06-28',
        },
      })
      .pipe(map((response) => response.data))
      .pipe(
        catchError((error) => {
          console.error(error);
          throw new ForbiddenException('API not available');
        }),
      );
  }

  patchPage() {
    return this.httpService
      .patch(
        `https://api.notion.com/v1/pages/a60cf6646de74a3987cdcf82a6adb45d`,
        {
          properties: {
            Progress: {
              number: 17,
            },
          },
        },
        {
          headers: {
            Authorization: `Bearer secret_iNcmYgO0zH7ftoXF9SiXlyiCJw71VVmZXeqUPde6NfF`,
            'Notion-Version': '2022-06-28',
            'Content-Type': 'application/json',
          },
        },
      )
      .pipe(map((response) => response.data))
      .pipe(
        catchError((error) => {
          console.error(error);
          throw new ForbiddenException('API not available');
        }),
      );
  }
}
